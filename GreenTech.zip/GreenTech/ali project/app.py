# app.py - Main Flask Application

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime, timedelta # Ensure timedelta is imported
import random
from werkzeug.security import generate_password_hash, check_password_hash
import os
from flask_mail import Mail, Message
import secrets
import jinja2 # Import jinja2

app = Flask(__name__)
# Enable the 'do' extension for Jinja
app.jinja_env.add_extension('jinja2.ext.do')
# Generate a secure secret key (or use environment variable in production)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
# Use an absolute path for the SQLite database to avoid ambiguity
db_path = os.path.join(app.instance_path, 'greenhouse.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Ensure the instance folder exists
try:
    os.makedirs(app.instance_path, exist_ok=True)
except OSError:
    pass

# Email configuration - IMPORTANT: Replace with your actual email credentials or use environment variables
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', 'your-email@gmail.com')  # Use env var or placeholder
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', 'your-email-password')   # Use env var or placeholder
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'your-email@gmail.com') # Use env var or placeholder

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
mail = Mail(app)

# Context Processor to inject variables into templates
@app.context_processor
def inject_now():
    return {'now': datetime.utcnow()} # Provides {{ now }} in templates

# Models
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    greenhouses = db.relationship('Greenhouse', backref='owner', lazy=True)

class Greenhouse(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(200), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plants = db.relationship('Plant', backref='greenhouse', lazy=True)
    # Changed relationship name to 'sensor' (singular) to match uselist=False
    sensor = db.relationship('Sensor', backref='greenhouse', lazy=True, uselist=False)
    alerts = db.relationship('Alert', backref='greenhouse', lazy=True)

class Plant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(100), nullable=False)
    planting_date = db.Column(db.DateTime, nullable=True)
    greenhouse_id = db.Column(db.Integer, db.ForeignKey('greenhouse.id'), nullable=False)
    optimal_temperature = db.Column(db.Float, nullable=True)
    optimal_humidity = db.Column(db.Float, nullable=True)
    optimal_soil_moisture = db.Column(db.Float, nullable=True)
    notes = db.Column(db.Text, nullable=True)

class Sensor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    greenhouse_id = db.Column(db.Integer, db.ForeignKey('greenhouse.id'), nullable=False, unique=True) # Ensure one sensor per greenhouse
    temperature = db.Column(db.Float, default=0)
    humidity = db.Column(db.Float, default=0)
    soil_moisture = db.Column(db.Float, default=0)
    air_quality = db.Column(db.Float, default=0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    history = db.relationship('SensorHistory', backref='sensor', lazy=True)

class SensorHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sensor_id = db.Column(db.Integer, db.ForeignKey('sensor.id'), nullable=False)
    temperature = db.Column(db.Float, default=0)
    humidity = db.Column(db.Float, default=0)
    soil_moisture = db.Column(db.Float, default=0)
    air_quality = db.Column(db.Float, default=0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    greenhouse_id = db.Column(db.Integer, db.ForeignKey('greenhouse.id'), nullable=False)
    message = db.Column(db.String(200), nullable=False)
    resolved = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    alert_type = db.Column(db.String(50), nullable=False)  # temperature, humidity, soil, air

@login_manager.user_loader
def load_user(user_id):
    # Use session.get to handle potential None value more gracefully
    return db.session.get(User, int(user_id))

# Helper Functions
def generate_sensor_data(greenhouse_id):
    """Generate random sensor data for demo purposes and check alerts"""
    sensor = Sensor.query.filter_by(greenhouse_id=greenhouse_id).first()

    if not sensor:
        print(f"Sensor not found for greenhouse {greenhouse_id}. Attempting to create.")
        try:
            sensor = Sensor(greenhouse_id=greenhouse_id)
            db.session.add(sensor)
            db.session.commit()
            print(f"Sensor created for greenhouse {greenhouse_id}.")
        except Exception as e:
             print(f"Error creating sensor for greenhouse {greenhouse_id}: {e}")
             db.session.rollback()
             return None # Cannot proceed without a sensor

    # Generate random values
    sensor.temperature = round(random.uniform(18.0, 30.0), 1)
    sensor.humidity = round(random.uniform(40.0, 80.0), 1)
    sensor.soil_moisture = round(random.uniform(30.0, 90.0), 1)
    sensor.air_quality = round(random.uniform(70.0, 100.0), 1) # Assuming higher is better for demo
    sensor.timestamp = datetime.utcnow()

    # Save history (only if sensor ID is available)
    if sensor.id:
        history = SensorHistory(
            sensor_id=sensor.id,
            temperature=sensor.temperature,
            humidity=sensor.humidity,
            soil_moisture=sensor.soil_moisture,
            air_quality=sensor.air_quality
        )
        db.session.add(history)
        db.session.commit() # Commit history separately
    else:
        print(f"Warning: Sensor ID not available for greenhouse {greenhouse_id}, cannot save history.")


    # Check for alerts
    check_alerts(greenhouse_id, sensor)

    return sensor

def check_alerts(greenhouse_id, sensor):
    """Check if sensor values trigger alerts. Only create new, unresolved alerts."""
    # Example thresholds - in a real app, these would be configurable per greenhouse/plant
    thresholds = {
        'temp_high': 28.0,
        'temp_low': 18.0, # Added low temp check
        'humidity_low': 45.0,
        'humidity_high': 80.0, # Added high humidity check
        'soil_low': 40.0,
        'soil_high': 90.0, # Added high soil moisture check
        'air_quality_low': 75.0 # Assuming lower is worse
    }

    # Check Temperature High
    if sensor.temperature > thresholds['temp_high']:
        create_alert(greenhouse_id, f"High temperature: {sensor.temperature}°C", "temperature")
    # Check Temperature Low
    elif sensor.temperature < thresholds['temp_low']:
         create_alert(greenhouse_id, f"Low temperature: {sensor.temperature}°C", "temperature")
    # Check Humidity Low
    if sensor.humidity < thresholds['humidity_low']:
        create_alert(greenhouse_id, f"Low humidity: {sensor.humidity}%", "humidity")
    # Check Humidity High
    elif sensor.humidity > thresholds['humidity_high']:
        create_alert(greenhouse_id, f"High humidity: {sensor.humidity}%", "humidity")
    # Check Soil Moisture Low
    if sensor.soil_moisture < thresholds['soil_low']:
        create_alert(greenhouse_id, f"Low soil moisture: {sensor.soil_moisture}%", "soil")
    # Check Soil Moisture High
    elif sensor.soil_moisture > thresholds['soil_high']:
        create_alert(greenhouse_id, f"High soil moisture: {sensor.soil_moisture}%", "soil")
    # Check Air Quality Low
    if sensor.air_quality < thresholds['air_quality_low']:
        create_alert(greenhouse_id, f"Poor air quality index: {sensor.air_quality}", "air")

def create_alert(greenhouse_id, message, alert_type):
    """Create a new alert only if an unresolved alert of the same type doesn't exist"""
    existing_alert = Alert.query.filter_by(
        greenhouse_id=greenhouse_id,
        alert_type=alert_type,
        resolved=False
    ).first()

    if not existing_alert:
        alert = Alert(
            greenhouse_id=greenhouse_id,
            message=message,
            alert_type=alert_type
        )
        db.session.add(alert)
        db.session.commit()

        # Send email notification to greenhouse owner
        greenhouse = db.session.get(Greenhouse, greenhouse_id) # Use session.get
        if greenhouse and greenhouse.owner and greenhouse.owner.is_verified: # Only notify verified users
            send_alert_email(greenhouse.owner.email, message, greenhouse.name)

def send_alert_email(email, message, greenhouse_name):
    """Send alert email to user"""
    subject = f"Alert: Issue in Greenhouse '{greenhouse_name}'"
    body = f"The following issue was detected in your greenhouse '{greenhouse_name}':\n\n{message}\n\nPlease check your greenhouse monitoring system dashboard for details and resolve the issue.\n\n- GreenTech Monitoring System"

    msg = Message(
        subject=subject,
        recipients=[email],
        body=body
    )
    try:
        mail.send(msg)
        print(f"Alert email sent to {email}")
    except Exception as e:
        print(f"Error sending alert email to {email}: {e}")
        # Log this error properly in a real application

def send_verification_email(email, token):
    """Send verification email to new user"""
    verify_url = url_for('verify_email', token=token, _external=True)
    subject = "Verify your GreenTech account"
    body = f"Welcome to GreenTech!\n\nPlease click the link below to verify your email address and activate your account:\n\n{verify_url}\n\nIf you did not sign up for GreenTech, please ignore this email.\n\n- The GreenTech Team"

    msg = Message(
        subject=subject,
        recipients=[email],
        body=body
    )
    try:
        mail.send(msg)
        print(f"Verification email sent to {email}")
    except Exception as e:
        print(f"Error sending verification email to {email}: {e}")
        # Log this error properly in a real application

# --- Routes ---
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password') # Added confirmation check

        if not username or not email or not password or not confirm_password:
            flash('All fields are required.', 'danger')
            return render_template('register.html', form_data=request.form)

        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html', form_data=request.form)

        user_exists = User.query.filter_by(username=username).first()
        email_exists = User.query.filter_by(email=email).first()

        if user_exists:
            flash('Username already exists. Please choose a different one.', 'danger')
            return render_template('register.html', form_data=request.form)

        if email_exists:
            flash('Email address already registered. Please login or use a different email.', 'danger')
            return render_template('register.html', form_data=request.form)

        verification_token = secrets.token_urlsafe(32)
        # Explicitly use pbkdf2:sha256 for broader compatibility
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        new_user = User(
            username=username,
            email=email,
            password=hashed_password,
            verification_token=verification_token,
            is_verified=False # Start as unverified
        )

        try:
            db.session.add(new_user)
            db.session.commit()
           # send_verification_email(email, verification_token)
            flash('Registration successful! Please check your email to verify your account.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.', 'danger')
            print(f"Registration error: {e}") # Log error
            return render_template('register.html', form_data=request.form)

    return render_template('register.html')

@app.route('/verify-email/<token>')
def verify_email(token):
    user = User.query.filter_by(verification_token=token).first()

    if not user:
        flash('Invalid or expired verification link. Please register again or contact support.', 'danger')
        return redirect(url_for('login'))

    if user.is_verified:
         flash('Your email is already verified. You can login.', 'info')
         return redirect(url_for('login'))

    user.is_verified = True
    user.verification_token = None # Clear the token once verified
    try:
        db.session.commit()
        flash('Your email has been verified successfully! You can now login.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred during email verification. Please try again or contact support.', 'danger')
        print(f"Verification error: {e}") # Log error

    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(email=email).first()

        # Check password, handling potential hashing algorithm issues
        password_match = False
        if user:
            try:
                password_match = check_password_hash(user.password, password)
            except ValueError as e:
                # Check if the error is due to an unsupported hash type (like scrypt)
                if 'unsupported hash type' in str(e):
                    flash('Login failed due to an account compatibility issue. Please try resetting your password or contact support.', 'danger')
                    print(f"Login error for {email}: Unsupported hash type detected. {e}") # Log specific error
                    return render_template('login.html')
                else:
                    # Re-raise other ValueErrors
                    raise e

        if not user or not password_match:
            flash('Invalid email or password. Please try again.', 'danger')
            return render_template('login.html') # Re-render login form

        if not user.is_verified:
         flash('Your email is already verified. You can login.', 'info')
         return redirect(url_for('login'))

        user.is_verified = True
        user.verification_token = None
            # Option to resend verification email could be added here
            #flash('Your account is not verified. Please check your email for the verification link.', 'warning')
            #return render_template('login.html') # Re-render login form

        login_user(user, remember=remember)
        flash(f'Welcome back, {user.username}!', 'success')
        # Redirect to intended page if available, otherwise dashboard
        next_page = request.args.get('next')
        return redirect(next_page or url_for('dashboard'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    user_greenhouses = Greenhouse.query.filter_by(user_id=current_user.id).order_by(Greenhouse.name).all()
    alerts = []

    for greenhouse in user_greenhouses:
        # Generate sensor data for each greenhouse (or fetch real data)
        generate_sensor_data(greenhouse.id)

        # Get active alerts for this greenhouse
        greenhouse_alerts = Alert.query.filter_by(
            greenhouse_id=greenhouse.id,
            resolved=False
        ).order_by(Alert.timestamp.desc()).all()
        alerts.extend(greenhouse_alerts)

    return render_template(
        'dashboard.html',
        greenhouses=user_greenhouses,
        alerts=alerts,
        is_admin=current_user.is_admin
    )

@app.route('/greenhouse/<int:id>')
@login_required
def greenhouse_detail(id):
    greenhouse = db.session.get(Greenhouse, id) # Use session.get for primary key lookup
    if not greenhouse:
        flash(f"Greenhouse with ID {id} not found.", "warning")
        return redirect(url_for('dashboard'))


    # Check if the current user owns this greenhouse or is an admin
    if greenhouse.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to view this greenhouse.', 'danger')
        return redirect(url_for('dashboard'))

    # Generate/fetch current sensor data
    sensor = generate_sensor_data(greenhouse.id) # Ensures sensor exists and data is fresh

    # Get sensor history for charts (last 20 records for example)
    sensor_history = []
    if sensor and sensor.id: # Only query history if sensor exists and has an ID
        sensor_history = SensorHistory.query.filter_by(
            sensor_id=sensor.id
        ).order_by(SensorHistory.timestamp.desc()).limit(20).all()
    elif not sensor:
         flash(f"Could not load or create sensor data for {greenhouse.name}.", "warning")


    # Get active alerts for this specific greenhouse
    alerts = Alert.query.filter_by(
        greenhouse_id=greenhouse.id,
        resolved=False
    ).order_by(Alert.timestamp.desc()).all()

    return render_template(
        'greenhouse_detail.html',
        greenhouse=greenhouse,
        sensor=sensor,
        sensor_history=sensor_history,
        alerts=alerts
    )

@app.route('/plants')
@login_required
def plants():
    # Get IDs of greenhouses owned by the current user
    user_greenhouse_ids = [g.id for g in Greenhouse.query.filter_by(user_id=current_user.id).all()]

    # Fetch plants only from the user's greenhouses
    all_plants = Plant.query.filter(
        Plant.greenhouse_id.in_(user_greenhouse_ids)
    ).order_by(Plant.name).all()

    # Fetch user's greenhouses for the filter dropdown
    user_greenhouses = Greenhouse.query.filter_by(user_id=current_user.id).order_by(Greenhouse.name).all()

    return render_template('plants.html', plants=all_plants, greenhouses=user_greenhouses)


@app.route('/add_plant', methods=['GET', 'POST'])
@login_required
def add_plant():
    user_greenhouses = Greenhouse.query.filter_by(user_id=current_user.id).order_by(Greenhouse.name).all()

    if not user_greenhouses:
        flash('You need to add a greenhouse before you can add plants.', 'warning')
        return redirect(url_for('add_greenhouse'))

    if request.method == 'POST':
        name = request.form.get('name')
        plant_type = request.form.get('type')
        greenhouse_id_str = request.form.get('greenhouse_id')
        planting_date_str = request.form.get('planting_date') # Get planting date string

        if not name or not plant_type or not greenhouse_id_str:
             flash('Name, Plant Type, and Greenhouse are required.', 'danger')
             return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)

        try:
            greenhouse_id = int(greenhouse_id_str)
        except ValueError:
            flash('Invalid greenhouse selection.', 'danger')
            return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)

        # Verify the selected greenhouse belongs to the current user
        greenhouse = Greenhouse.query.filter_by(id=greenhouse_id, user_id=current_user.id).first()
        if not greenhouse:
            flash('Invalid greenhouse selection.', 'danger')
            return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)

        # Process planting date
        planting_date = None
        if planting_date_str:
            try:
                planting_date = datetime.strptime(planting_date_str, '%Y-%m-%d')
            except ValueError:
                flash('Invalid planting date format. Please use YYYY-MM-DD.', 'danger')
                return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)


        # Add optional parameters with validation
        optimal_temp_str = request.form.get('optimal_temperature')
        optimal_humidity_str = request.form.get('optimal_humidity')
        optimal_soil_str = request.form.get('optimal_soil_moisture')
        notes = request.form.get('notes')

        try:
            optimal_temp = float(optimal_temp_str) if optimal_temp_str else None
            optimal_humidity = float(optimal_humidity_str) if optimal_humidity_str else None
            optimal_soil = float(optimal_soil_str) if optimal_soil_str else None
        except ValueError:
             flash('Optimal values must be numbers.', 'danger')
             return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)


        # Create new plant
        new_plant = Plant(
            name=name,
            type=plant_type,
            greenhouse_id=greenhouse_id,
            planting_date=planting_date, # Use processed date
            optimal_temperature=optimal_temp,
            optimal_humidity=optimal_humidity,
            optimal_soil_moisture=optimal_soil,
            notes=notes
        )

        try:
            db.session.add(new_plant)
            db.session.commit()
            flash(f'Plant "{name}" added successfully to {greenhouse.name}!', 'success')
            return redirect(url_for('plants'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while adding the plant.', 'danger')
            print(f"Add plant error: {e}") # Log error
            return render_template('add_plant.html', greenhouses=user_greenhouses, form_data=request.form)


    # Pre-select greenhouse if passed via query parameter
    selected_gh_id = request.args.get('greenhouse_id', type=int)
    return render_template('add_plant.html', greenhouses=user_greenhouses, selected_gh_id=selected_gh_id)

@app.route('/add_greenhouse', methods=['GET', 'POST'])
@login_required
def add_greenhouse():
    if request.method == 'POST':
        name = request.form.get('name')
        location = request.form.get('location')

        if not name:
            flash('Greenhouse name is required.', 'danger')
            return render_template('add_greenhouse.html', form_data=request.form)

        new_greenhouse = Greenhouse(
            name=name,
            location=location,
            user_id=current_user.id
        )

        try:
            db.session.add(new_greenhouse)
            db.session.commit()
            # Also create a sensor entry for the new greenhouse
            new_sensor = Sensor(greenhouse_id=new_greenhouse.id)
            db.session.add(new_sensor)
            db.session.commit()
            flash(f'Greenhouse "{name}" added successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while adding the greenhouse.', 'danger')
            print(f"Add greenhouse error: {e}") # Log error
            return render_template('add_greenhouse.html', form_data=request.form)


    return render_template('add_greenhouse.html')

@app.route('/resolve_alert/<int:id>', methods=['POST'])
@login_required
def resolve_alert(id):
    alert = db.session.get(Alert, id) # Use session.get
    if not alert:
         return jsonify({'success': False, 'error': 'Alert not found'}), 404

    greenhouse = db.session.get(Greenhouse, alert.greenhouse_id)

    # Check if user owns the greenhouse or is admin
    if not greenhouse or (greenhouse.user_id != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Permission denied'}), 403

    if alert.resolved:
        return jsonify({'success': False, 'error': 'Alert already resolved'}), 400

    alert.resolved = True
    try:
        db.session.commit()
        return jsonify({'success': True, 'message': 'Alert resolved successfully'})
    except Exception as e:
        db.session.rollback()
        print(f"Resolve alert error: {e}") # Log error
        return jsonify({'success': False, 'error': 'Database error occurred'}), 500


@app.route('/api/sensor_data/<int:greenhouse_id>')
@login_required
def api_sensor_data(greenhouse_id):
    greenhouse = db.session.get(Greenhouse, greenhouse_id) # Use session.get
    if not greenhouse:
        return jsonify({'error': 'Greenhouse not found'}), 404

    # Check if user owns the greenhouse or is admin
    if greenhouse.user_id != current_user.id and not current_user.is_admin:
        return jsonify({'error': 'Permission denied'}), 403

    # Generate/fetch new sensor data
    sensor = generate_sensor_data(greenhouse_id) # Or fetch real data

    if not sensor:
         return jsonify({'error': 'Sensor data not available'}), 404

    return jsonify({
        'temperature': sensor.temperature,
        'humidity': sensor.humidity,
        'soil_moisture': sensor.soil_moisture,
        'air_quality': sensor.air_quality,
        'timestamp': sensor.timestamp.strftime('%Y-%m-%d %H:%M:%S') # Use ISO format or consistent format
    })

@app.route('/admin')
@login_required
def admin_panel():
    if not current_user.is_admin:
        flash('Admin access required.', 'danger')
        return redirect(url_for('dashboard'))

    users = User.query.order_by(User.username).all()
    greenhouses = Greenhouse.query.order_by(Greenhouse.name).all()
    # Fetch all unresolved alerts for the admin view
    alerts = Alert.query.filter_by(resolved=False).order_by(Alert.timestamp.desc()).all()

    return render_template(
        'admin.html',
        users=users,
        greenhouses=greenhouses,
        alerts=alerts
    )

@app.route('/admin/make_admin/<int:user_id>', methods=['POST'])
@login_required
def make_admin(user_id):
    if not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Permission denied'}), 403

    user = db.session.get(User, user_id) # Use session.get
    if not user:
         return jsonify({'success': False, 'error': 'User not found'}), 404


    if user.id == current_user.id:
         return jsonify({'success': False, 'error': 'Cannot change your own admin status'}), 400

    user.is_admin = not user.is_admin # Toggle admin status
    action = "granted" if user.is_admin else "revoked"

    try:
        db.session.commit()
        return jsonify({'success': True, 'message': f'Admin status {action} for user {user.username}.'})
    except Exception as e:
        db.session.rollback()
        print(f"Make admin error: {e}") # Log error
        return jsonify({'success': False, 'error': 'Database error occurred'}), 500

# Add routes for deleting users/greenhouses (with confirmation) if needed for admin panel

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')

        if not name or not email or not subject or not message:
            flash('All fields are required.', 'danger')
            return render_template('contact.html', form_data=request.form)

        # Send email to admin (replace with actual admin email)
        admin_email = app.config.get('MAIL_DEFAULT_SENDER') # Send to configured sender/admin
        msg = Message(
            subject=f"Contact Form: {subject}",
            sender=app.config['MAIL_DEFAULT_SENDER'], # Use configured sender
            recipients=[admin_email],
            reply_to=email, # Set reply-to for easy response
            body=f"Message from: {name} <{email}>\n\nSubject: {subject}\n\nMessage:\n{message}"
        )
        try:
            mail.send(msg)
            flash('Your message has been sent successfully! We will get back to you soon.', 'success')
            return redirect(url_for('contact')) # Redirect after successful POST
        except Exception as e:
            flash('An error occurred while sending your message. Please try again later or contact us directly.', 'danger')
            print(f"Contact form error: {e}") # Log error

    return render_template('contact.html')

# Dummy route to catch unrelated socket.io requests from browser extensions
@app.route('/socket.io/', defaults={'path': ''})
@app.route('/socket.io/<path:path>')
def socketio_dummy(path):
    # Return a simple 200 OK with no content to silence 404s in logs
    return '', 200

# --- Initialization ---
_db_initialized = False

def init_db():
    """Initializes the database; creates tables and seeds data if needed."""
    global _db_initialized
    if _db_initialized:
        return

    with app.app_context():
        print("Attempting to initialize database...")
        try:
            db.create_all()
            print("Database tables created (if they didn't exist).")

            # Create admin user if it doesn't exist
            admin_email = 'admin@greentech.com' # Use consistent email
            admin = User.query.filter_by(email=admin_email).first()
            admin_created_now = False # Flag to check if we just created the admin
            if not admin:
                admin_password = 'admin123' # Change this in production!
                admin = User(
                    username='admin',
                    email=admin_email,
                    # Use default hashing (recommended) -> Changed in register, ensure consistency if needed
                    password=generate_password_hash(admin_password, method='pbkdf2:sha256'), # Use consistent method
                    is_admin=True,
                    is_verified=True # Admin is verified by default
                )
                db.session.add(admin)
                db.session.commit()
                admin_created_now = True # Set flag as we just created the admin
                print(f"Admin user created with email '{admin_email}' and password '{admin_password}'. CHANGE THIS PASSWORD.")
            else:
                print("Admin user already exists.")
                # Check if existing admin password needs updating due to hash incompatibility or change
                if admin: # Ensure admin object exists before checking password
                    try:
                        # Attempt to check the hash. This might fail if the hash type is unsupported.
                        if not check_password_hash(admin.password, 'admin123'):
                            print("Admin password mismatch detected. Updating password hash...")
                            admin.password = generate_password_hash('admin123', method='pbkdf2:sha256')
                            db.session.commit()
                            print("Admin password hash updated to pbkdf2:sha256.")
                    except ValueError as e:
                        # Specifically catch unsupported hash type errors during the check
                        if 'unsupported hash type' in str(e):
                            print("Admin password hash uses unsupported type. Updating password hash...")
                            admin.password = generate_password_hash('admin123', method='pbkdf2:sha256')
                            db.session.commit()
                            print("Admin password hash updated to pbkdf2:sha256.")
                        else:
                            # Re-raise other ValueErrors encountered during the check
                            print(f"Unexpected error checking admin password hash: {e}")
                            # Optionally re-raise e here if you want the app to stop on other errors

            # --- Add Random Sample Data ---
            # Add sample data only if the admin user exists and has no greenhouses
            # Also ensure sample data is added only if the admin was just created OR if no greenhouses exist for the admin
            if admin and (admin_created_now or not Greenhouse.query.filter_by(user_id=admin.id).first()):
                print("Admin user found with no greenhouses or was just created. Adding random sample data...")
                try:
                    num_greenhouses = random.randint(3, 5) # Create 3 to 5 greenhouses
                    greenhouse_names = ["Alpha House", "Beta Garden", "Gamma Project", "Delta Dome", "Epsilon Nursery", "Zeta Farm"]
                    locations = ["North Field", "South Plot", "Rooftop Unit", "West Wing", "East Annex", "Hydroponics Lab"]
                    plant_names = ["Tomato", "Cucumber", "Lettuce", "Strawberry", "Pepper", "Basil", "Mint", "Rosemary", "Lavender", "Orchid", "Succulent Mix", "Fern"]
                    plant_types = ["Vegetable", "Fruit", "Herb", "Flower", "Succulent", "Foliage"]
                    notes_options = ["Needs bright light.", "Keep soil consistently moist.", "Fertilize weekly.", "Prone to aphids.", None, "Slow grower."]

                    created_greenhouses = []
                    for i in range(num_greenhouses):
                        gh_name = f"{random.choice(greenhouse_names)} {i+1}"
                        gh_location = random.choice(locations)
                        new_gh = Greenhouse(name=gh_name, location=gh_location, owner=admin)
                        db.session.add(new_gh)
                        created_greenhouses.append(new_gh)

                    db.session.commit() # Commit greenhouses to get IDs

                    # Add sensors and plants for each created greenhouse
                    for gh in created_greenhouses:
                        # Add Sensor
                        new_sensor = Sensor(greenhouse_id=gh.id)
                        db.session.add(new_sensor)
                        db.session.commit() # Commit sensor

                        # Add Plants
                        num_plants = random.randint(2, 6) # Add 2 to 6 plants per greenhouse
                        plants_to_add = []
                        for _ in range(num_plants):
                            p_name = f"{random.choice(plant_names)} {random.randint(1,100)}"
                            p_type = random.choice(plant_types)
                            p_notes = random.choice(notes_options)
                            p_temp = round(random.uniform(18.0, 28.0), 1) if random.random() > 0.3 else None # 70% chance
                            p_humid = round(random.uniform(50.0, 75.0), 1) if random.random() > 0.4 else None # 60% chance
                            p_soil = round(random.uniform(40.0, 60.0), 1) if random.random() > 0.5 else None # 50% chance
                            p_date = datetime.utcnow() - timedelta(days=random.randint(5, 60)) # Planted sometime in last 2 months

                            new_plant = Plant(
                                name=p_name, type=p_type, greenhouse=gh,
                                optimal_temperature=p_temp, optimal_humidity=p_humid,
                                optimal_soil_moisture=p_soil, notes=p_notes,
                                planting_date=p_date
                            )
                            plants_to_add.append(new_plant)
                        db.session.add_all(plants_to_add)
                        db.session.commit() # Commit plants for this greenhouse

                    print(f"Added {len(created_greenhouses)} random greenhouses and associated plants/sensors for admin user.")

                except Exception as e:
                    db.session.rollback()
                    print(f"Error adding random sample data: {e}")
            elif admin:
                 print("Admin user already exists and has greenhouses. Skipping sample data addition.")
            # --- End Random Sample Data ---

        except Exception as e:
            print(f"Database initialization failed: {e}")

    _db_initialized = True


@app.before_request
def before_request_func():
    # Initialize DB before the first request (or any request if not yet initialized)
    init_db()

if __name__ == '__main__':
    # Use host='0.0.0.0' to make it accessible on the network if needed
    # Turn debug=True on for development server for better error pages and auto-reloading
    app.run(debug=True, host='127.0.0.1', port=5000)
